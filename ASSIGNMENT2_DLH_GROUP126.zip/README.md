# dse-dsad-grp126-work2
M Tech - DSE DSAD Group-126 Assignment02 for SEM1

# Deliverable Checklist
## need to clarify from faculty for name as assingment1 as it should be 2
1. Assignment Submission name :  ASSIGNMENT1_DLH_GROUP126.zip
2. design PS6_GROUP126.docx detailing your algorithm design and time complexity of the algorithm.
3. Zipped AS2_PS6_HE_GROUP126.py  package folder containing all the modules classes and functions and the main body of the program.
4. inputPS6.txt file used for testing
5. outputPS6.txt file generated while testing

## Developers :
- Anand R K
- Kamran Ali
- Pratik Prakash

| Priority Order  | Feature | Owner | Reviewer | Status|
| ------------- | ------------- |------------- |------------- |------------- |
| 1  | Add def read_input_file(path) to read inputs from inputPS6.txt  | Kamran  | Pratik | Done |
| 1 | Reading input from inputPS6.txt to form that weighted graph  |  Kamran| Pratik | Done |
| 1 | Printing shortest Path from created weighted graph - on outputPS6.txt | Kamran | Pratik | Done |
| 2 | Time Taken to reach on an avg speed on outputPS6.txt | Pratik |  Kamran | Done |
| 2 | Design document - detailing algo design and time complexity | Anand | Pratik |
| 3 | Deliverable preparation | Anand | Pratik  | |
| 3 | Final Review and Submission | Pratik | Kamran  | |

## Run script 
AS2_PS6_HE_G126.py

## Zip - AS2_PS6_HE_G126.zip
extract it and run script AS2_PS6_HE_G126.py with all files including output.txt and input.txt at level (same folder) after extracting .zip script